import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib

os.makedirs("model", exist_ok=True)

# Reproducible sample house-price dataset for this educational project.
# Features: area(sqft), bedrooms, bathrooms, stories, parking, age(years)
rng = np.random.default_rng(42)
n = 1000

area = rng.integers(500, 4001, n)
bedrooms = rng.integers(1, 6, n)
bathrooms = rng.integers(1, 5, n)
stories = rng.integers(1, 4, n)
parking = rng.integers(0, 4, n)
age = rng.integers(0, 31, n)

noise = rng.normal(0, 250000, n)
price = (
    1800 * area
    + 450000 * bedrooms
    + 300000 * bathrooms
    + 250000 * stories
    + 180000 * parking
    - 25000 * age
    + noise
)

df = pd.DataFrame({
    "area": area,
    "bedrooms": bedrooms,
    "bathrooms": bathrooms,
    "stories": stories,
    "parking": parking,
    "age": age,
    "price": price
})

X = df.drop("price", axis=1)
y = df["price"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestRegressor(
    n_estimators=200,
    random_state=42
)
model.fit(X_train, y_train)

pred = model.predict(X_test)
mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))
r2 = r2_score(y_test, pred)

joblib.dump(model, "model/house_price_model.pkl")
df.to_csv("house_prices.csv", index=False)

with open("model/metrics.txt", "w") as f:
    f.write(f"MAE: {mae:.2f}\n")
    f.write(f"RMSE: {rmse:.2f}\n")
    f.write(f"R2 Score: {r2:.4f}\n")

print("Model trained successfully!")
print(f"R2 Score: {r2:.4f}")
print("Saved: model/house_price_model.pkl")
