from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

model = joblib.load("model/house_price_model.pkl")

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    error = None

    if request.method == "POST":
        try:
            area = float(request.form["area"])
            bedrooms = float(request.form["bedrooms"])
            bathrooms = float(request.form["bathrooms"])
            stories = float(request.form["stories"])
            parking = float(request.form["parking"])
            age = float(request.form["age"])

            features = np.array([[area, bedrooms, bathrooms, stories, parking, age]])
            price = model.predict(features)[0]
            prediction = f"₹ {price:,.0f}"
        except Exception as e:
            error = "Please enter valid numbers in all fields."

    return render_template("index.html", prediction=prediction, error=error)

if __name__ == "__main__":
    app.run(debug=True)
