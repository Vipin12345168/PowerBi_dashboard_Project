HOUSE PRICE PREDICTION - MACHINE LEARNING PROJECT

Technology:
- Python
- Flask
- NumPy
- Pandas
- Scikit-learn
- HTML/CSS
- Random Forest Regression

HOW TO RUN:

1. Open this folder in VS Code.

2. Open VS Code Terminal.

3. Create virtual environment (optional):
   python -m venv venv

4. Activate it on Windows:
   venv\Scripts\activate

5. Install libraries:
   pip install -r requirements.txt

6. Train the ML model:
   python train_model.py

7. Start the website:
   python app.py

8. Open in browser:
   http://127.0.0.1:5000/

PROJECT FLOW:
User enters house details
        ↓
Flask receives form data
        ↓
Trained Random Forest model
        ↓
Model predicts price
        ↓
Predicted price displayed on website

IMPORTANT:
The included dataset is synthetic and is intended for learning/demo purposes.
For a real-world project, replace it with a reliable local housing dataset and retrain the model.
